import StickyHeader from "@/components/landing/StickyHeader";
import Footer from "@/components/landing/Footer";
import SEO from "@/components/SEO";

const PrivacyPolicy = () => (
  <>
    <SEO
      title="Privacy Policy | SonoView For You"
      description="Read SonoView For You's privacy policy: how we collect, use, and protect personal and health information for our Reno, NV ultrasound services."
    />
    <StickyHeader />
    <main className="container mx-auto px-4 py-12 max-w-3xl font-body">
      <h1 className="text-3xl font-bold font-display text-foreground mb-2">PRIVACY POLICY</h1>
      <p className="text-sm text-muted-foreground mb-8">Last updated February 17, 2026</p>

      <section className="space-y-4 text-sm leading-relaxed text-foreground/90">
        <p>This Privacy Notice for Sonoview For You LLC (doing business as SonoView For You) ("<strong>we</strong>," "<strong>us</strong>," or "<strong>our</strong>"), describes how and why we might access, collect, store, use, and/or share ("<strong>process</strong>") your personal information when you use our services ("<strong>Services</strong>"), including when you:</p>
        <ul className="list-disc pl-6 space-y-2">
          <li>Visit our website at <a href="http://sonoviewforyou.com" className="text-primary underline">http://sonoviewforyou.com</a> or any website of ours that links to this Privacy Notice</li>
          <li>Download and use our Facebook application (SonoView For You), or any other application of ours that links to this Privacy Notice</li>
          <li>Use Ultrasound Services. SonoView For You is a private ultrasound provider offering pregnancy imaging, general medical ultrasound, and preventative wellness ultrasound services in a professional clinical setting. We collect limited personal information necessary to schedule appointments, communicate with patients, and deliver our services.</li>
          <li>Engage with us in other related ways, including any marketing or events</li>
        </ul>
        <p><strong>Questions or concerns?</strong> Reading this Privacy Notice will help you understand your privacy rights and choices. We are responsible for making decisions about how your personal information is processed. If you do not agree with our policies and practices, please do not use our Services. If you still have any questions or concerns, please contact us at <a href="mailto:care@sonoviewforyou.com" className="text-primary underline">care@sonoviewforyou.com</a>.</p>

        <h2 className="text-xl font-bold font-display text-foreground mt-10 mb-4">SUMMARY OF KEY POINTS</h2>
        <p className="italic"><strong>This summary provides key points from our Privacy Notice, but you can find out more details about any of these topics by clicking the link following each key point or by using our table of contents below to find the section you are looking for.</strong></p>
        <p><strong>What personal information do we process?</strong> When you visit, use, or navigate our Services, we may process personal information depending on how you interact with us and the Services, the choices you make, and the products and features you use.</p>
        <p><strong>Do we process any sensitive personal information?</strong> Some of the information may be considered "special" or "sensitive" in certain jurisdictions, for example your racial or ethnic origins, sexual orientation, and religious beliefs. We may process sensitive personal information when necessary with your consent or as otherwise permitted by applicable law.</p>
        <p><strong>Do we collect any information from third parties?</strong> We do not collect any information from third parties.</p>
        <p><strong>How do we process your information?</strong> We process your information to provide, improve, and administer our Services, communicate with you, for security and fraud prevention, and to comply with law. We may also process your information for other purposes with your consent. We process your information only when we have a valid legal reason to do so.</p>
        <p><strong>In what situations and with which types of parties do we share personal information?</strong> We may share information in specific situations and with specific categories of third parties.</p>
        <p><strong>How do we keep your information safe?</strong> We have adequate organizational and technical processes and procedures in place to protect your personal information. However, no electronic transmission over the internet or information storage technology can be guaranteed to be 100% secure, so we cannot promise or guarantee that hackers, cybercriminals, or other unauthorized third parties will not be able to defeat our security and improperly collect, access, steal, or modify your information.</p>
        <p><strong>What are your rights?</strong> Depending on where you are located geographically, the applicable privacy law may mean you have certain rights regarding your personal information.</p>
        <p><strong>How do you exercise your rights?</strong> The easiest way to exercise your rights is by submitting a data subject access request, or by contacting us. We will consider and act upon any request in accordance with applicable data protection laws.</p>

        <h2 className="text-xl font-bold font-display text-foreground mt-10 mb-4">TABLE OF CONTENTS</h2>
        <ol className="list-decimal pl-6 space-y-1">
          <li><a href="#pp-1" className="text-primary underline">WHAT INFORMATION DO WE COLLECT?</a></li>
          <li><a href="#pp-2" className="text-primary underline">HOW DO WE PROCESS YOUR INFORMATION?</a></li>
          <li><a href="#pp-3" className="text-primary underline">WHAT LEGAL BASES DO WE RELY ON TO PROCESS YOUR PERSONAL INFORMATION?</a></li>
          <li><a href="#pp-4" className="text-primary underline">WHEN AND WITH WHOM DO WE SHARE YOUR PERSONAL INFORMATION?</a></li>
          <li><a href="#pp-5" className="text-primary underline">DO WE USE COOKIES AND OTHER TRACKING TECHNOLOGIES?</a></li>
          <li><a href="#pp-6" className="text-primary underline">IS YOUR INFORMATION TRANSFERRED INTERNATIONALLY?</a></li>
          <li><a href="#pp-7" className="text-primary underline">HOW LONG DO WE KEEP YOUR INFORMATION?</a></li>
          <li><a href="#pp-8" className="text-primary underline">HOW DO WE KEEP YOUR INFORMATION SAFE?</a></li>
          <li><a href="#pp-9" className="text-primary underline">DO WE COLLECT INFORMATION FROM MINORS?</a></li>
          <li><a href="#pp-10" className="text-primary underline">WHAT ARE YOUR PRIVACY RIGHTS?</a></li>
          <li><a href="#pp-11" className="text-primary underline">CONTROLS FOR DO-NOT-TRACK FEATURES</a></li>
        </ol>

        <h2 id="pp-1" className="text-xl font-bold font-display text-foreground mt-10 mb-4">1. WHAT INFORMATION DO WE COLLECT?</h2>
        <h3 className="text-base font-bold text-foreground mt-6 mb-2">Personal information you disclose to us</h3>
        <p className="italic"><strong>In Short:</strong> We collect personal information that you provide to us.</p>
        <p>We collect personal information that you voluntarily provide to us when you express an interest in obtaining information about us or our products and Services, when you participate in activities on the Services, or otherwise when you contact us.</p>
        <p><strong>Personal Information Provided by You.</strong> The personal information that we collect depends on the context of your interactions with us and the Services, the choices you make, and the products and features you use. The personal information we collect may include the following:</p>
        <ul className="list-disc pl-6 space-y-2">
          <li>names</li>
          <li>phone numbers</li>
          <li>email addresses</li>
          <li>mailing addresses</li>
          <li>billing addresses</li>
          <li>debit/credit card numbers</li>
          <li>contact preferences</li>
        </ul>
        <p><strong>Sensitive Information.</strong> When necessary, with your consent or as otherwise permitted by applicable law, we process the following categories of sensitive information:</p>
        <ul className="list-disc pl-6 space-y-2">
          <li>health data</li>
          <li>financial data</li>
        </ul>
        <p><strong>Payment Data.</strong> We may collect data necessary to process your payment if you choose to make purchases, such as your payment instrument number, and the security code associated with your payment instrument. All payment data is handled and stored by Wix Payments. You may find their privacy notice link(s) here: <a href="https://www.wix.com/about/privacy" className="text-primary underline">https://www.wix.com/about/privacy</a>.</p>
        <p><strong>Application Data.</strong> If you use our application(s), we also may collect the following information if you choose to provide us with access or permission:</p>
        <ul className="list-disc pl-6 space-y-2">
          <li><em>Mobile Device Data.</em> We automatically collect device information (such as your mobile device ID, model, and manufacturer), operating system, version information and system configuration information, device and application identification numbers, browser type and version, hardware model Internet service provider and/or mobile carrier, and Internet Protocol (IP) address (or proxy server). If you are using our application(s), we may also collect information about the phone network associated with your mobile device, your mobile device's operating system or platform, the type of mobile device you use, your mobile device's unique device ID, and information about the features of our application(s) you accessed.</li>
        </ul>
        <p>This information is primarily needed to maintain the security and operation of our application(s), for troubleshooting, and for our internal analytics and reporting purposes.</p>
        <p>All personal information that you provide to us must be true, complete, and accurate, and you must notify us of any changes to such personal information.</p>

        <h3 className="text-base font-bold text-foreground mt-6 mb-2">Information automatically collected</h3>
        <p className="italic"><strong>In Short:</strong> Some information — such as your Internet Protocol (IP) address and/or browser and device characteristics — is collected automatically when you visit our Services.</p>
        <p>We automatically collect certain information when you visit, use, or navigate the Services. This information does not reveal your specific identity (like your name or contact information) but may include device and usage information, such as your IP address, browser and device characteristics, operating system, language preferences, referring URLs, device name, country, location, information about how and when you use our Services, and other technical information. This information is primarily needed to maintain the security and operation of our Services, and for our internal analytics and reporting purposes.</p>
        <p>Like many businesses, we also collect information through cookies and similar technologies.</p>
        <p>The information we collect includes:</p>
        <ul className="list-disc pl-6 space-y-2">
          <li><em>Log and Usage Data.</em> Log and usage data is service-related, diagnostic, usage, and performance information our servers automatically collect when you access or use our Services and which we record in log files. Depending on how you interact with us, this log data may include your IP address, device information, browser type, and settings and information about your activity in the Services (such as the date/time stamps associated with your usage, pages and files viewed, searches, and other actions you take such as which features you use), device event information (such as system activity, error reports (sometimes called "crash dumps"), and hardware settings).</li>
          <li><em>Device Data.</em> We collect device data such as information about your computer, phone, tablet, or other device you use to access the Services. Depending on the device used, this device data may include information such as your IP address (or proxy server), device and application identification numbers, location, browser type, hardware model, Internet service provider and/or mobile carrier, operating system, and system configuration information.</li>
          <li><em>Location Data.</em> We collect location data such as information about your device's location, which can be either precise or imprecise. How much information we collect depends on the type and settings of the device you use to access the Services. For example, we may use GPS and other technologies to collect geolocation data that tells us your current location (based on your IP address). You can opt out of allowing us to collect this information either by refusing access to the information or by disabling your Location setting on your device. However, if you choose to opt out, you may not be able to use certain aspects of the Services.</li>
        </ul>
        <p><strong>Information collected when you use our Facebook application(s).</strong> We by default access your Facebook basic account information, including your name, email, gender, birthday, current city, and profile picture URL, as well as other information that you choose to make public. We may also request access to other permissions related to your account, such as friends, check-ins, and likes, and you may choose to grant or deny us access to each individual permission. For more information regarding Facebook permissions, refer to the <a href="https://developers.facebook.com/docs/permissions/reference" className="text-primary underline">Facebook Permissions Reference</a> page.</p>

        <h2 id="pp-2" className="text-xl font-bold font-display text-foreground mt-10 mb-4">2. HOW DO WE PROCESS YOUR INFORMATION?</h2>
        <p className="italic"><strong>In Short:</strong> We process your information to provide, improve, and administer our Services, communicate with you, for security and fraud prevention, and to comply with law. We may also process your information for other purposes only with your prior explicit consent.</p>
        <p><strong>We process your personal information for a variety of reasons, depending on how you interact with our Services, including:</strong></p>
        <ul className="list-disc pl-6 space-y-2">
          <li><strong>To deliver and facilitate delivery of services to the user.</strong> We may process your information to provide you with the requested service.</li>
          <li><strong>To respond to user inquiries/offer support to users.</strong> We may process your information to respond to your inquiries and solve any potential issues you might have with the requested service.</li>
          <li><strong>To send administrative information to you.</strong> We may process your information to send you details about our products and services, changes to our terms and policies, and other similar information.</li>
          <li><strong>To fulfill and manage your orders.</strong> We may process your information to fulfill and manage your orders, payments, returns, and exchanges made through the Services.</li>
          <li><strong>To send you marketing and promotional communications.</strong> We may process the personal information you send to us for our marketing purposes, if this is in accordance with your marketing preferences. You can opt out of our marketing emails at any time.</li>
          <li><strong>To protect our Services.</strong> We may process your information as part of our efforts to keep our Services safe and secure, including fraud monitoring and prevention.</li>
          <li><strong>To identify usage trends.</strong> We may process information about how you use our Services to better understand how they are being used so we can improve them.</li>
          <li><strong>To determine the effectiveness of our marketing and promotional campaigns.</strong> We may process your information to better understand how to provide marketing and promotional campaigns that are most relevant to you.</li>
          <li><strong>To save or protect an individual's vital interest.</strong> We may process your information when necessary to save or protect an individual's vital interest, such as to prevent harm.</li>
        </ul>

        <h2 id="pp-3" className="text-xl font-bold font-display text-foreground mt-10 mb-4">3. WHAT LEGAL BASES DO WE RELY ON TO PROCESS YOUR INFORMATION?</h2>
        <p className="italic"><strong>In Short:</strong> We only process your personal information when we believe it is necessary and we have a valid legal reason (i.e., legal basis) to do so under applicable law, like with your consent, to comply with laws, to provide you with services to enter into or fulfill our contractual obligations, to protect your rights, or to fulfill our legitimate business interests.</p>
        <p className="underline italic"><strong>If you are located in the EU or UK, this section applies to you.</strong></p>
        <p>The General Data Protection Regulation (GDPR) and UK GDPR require us to explain the valid legal bases we rely on in order to process your personal information. As such, we may rely on the following legal bases to process your personal information:</p>
        <ul className="list-disc pl-6 space-y-2">
          <li><strong>Consent.</strong> We may process your information if you have given us permission (i.e., consent) to use your personal information for a specific purpose. You can withdraw your consent at any time.</li>
          <li><strong>Performance of a Contract.</strong> We may process your personal information when we believe it is necessary to fulfill our contractual obligations to you, including providing our Services or at your request prior to entering into a contract with you.</li>
          <li><strong>Legitimate Interests.</strong> We may process your information when we believe it is reasonably necessary to achieve our legitimate business interests and those interests do not outweigh your interests and fundamental rights and freedoms. For example, we may process your personal information for some of the purposes described in order to:
            <ul className="list-disc pl-6 space-y-1 mt-1">
              <li>Send users information about special offers and discounts on our products and services</li>
              <li>Analyze how our Services are used so we can improve them to engage and retain users</li>
              <li>Support our marketing activities</li>
              <li>Diagnose problems and/or prevent fraudulent activities</li>
            </ul>
          </li>
          <li><strong>Legal Obligations.</strong> We may process your information where we believe it is necessary for compliance with our legal obligations, such as to cooperate with a law enforcement body or regulatory agency, exercise or defend our legal rights, or disclose your information as evidence in litigation in which we are involved.</li>
          <li><strong>Vital Interests.</strong> We may process your information where we believe it is necessary to protect your vital interests or the vital interests of a third party, such as situations involving potential threats to the safety of any person.</li>
        </ul>
        <p className="underline italic mt-6"><strong>If you are located in Canada, this section applies to you.</strong></p>
        <p>We may process your information if you have given us specific permission (i.e., express consent) to use your personal information for a specific purpose, or in situations where your permission can be inferred (i.e., implied consent). You can withdraw your consent at any time.</p>
        <p>In some exceptional cases, we may be legally permitted under applicable law to process your information without your consent, including, for example:</p>
        <ul className="list-disc pl-6 space-y-2">
          <li>If collection is clearly in the interests of an individual and consent cannot be obtained in a timely way</li>
          <li>For investigations and fraud detection and prevention</li>
          <li>For business transactions provided certain conditions are met</li>
          <li>If it is contained in a witness statement and the collection is necessary to assess, process, or settle an insurance claim</li>
          <li>For identifying injured, ill, or deceased persons and communicating with next of kin</li>
          <li>If we have reasonable grounds to believe an individual has been, is, or may be victim of financial abuse</li>
          <li>If it is reasonable to expect collection and use with consent would compromise the availability or the accuracy of the information and the collection is reasonable for purposes related to investigating a breach of an agreement or a contravention of the laws of Canada or a province</li>
          <li>If disclosure is required to comply with a subpoena, warrant, court order, or rules of the court relating to the production of records</li>
          <li>If it was produced by an individual in the course of their employment, business, or profession and the collection is consistent with the purposes for which the information was produced</li>
          <li>If the collection is solely for journalistic, artistic, or literary purposes</li>
          <li>If the information is publicly available and is specified by the regulations</li>
          <li>We may disclose de-identified information for approved research or statistics projects, subject to ethics oversight and confidentiality commitments</li>
        </ul>

        <h2 id="pp-4" className="text-xl font-bold font-display text-foreground mt-10 mb-4">4. WHEN AND WITH WHOM DO WE SHARE YOUR PERSONAL INFORMATION?</h2>
        <p className="italic"><strong>In Short:</strong> We may share information in specific situations described in this section and/or with the following categories of third parties.</p>
        <p><strong>Vendors, Consultants, and Other Third-Party Service Providers.</strong> We may share your data with third-party vendors, service providers, contractors, or agents ("<strong>third parties</strong>") who perform services for us or on our behalf and require access to such information to do that work. We have contracts in place with our third parties, which are designed to help safeguard your personal information. This means that they cannot do anything with your personal information unless we have instructed them to do it. They will also not share your personal information with any organization apart from us. They also commit to protect the data they hold on our behalf and to retain it for the period we instruct.</p>
        <p>The categories of third parties we may share personal information with are as follows:</p>
        <ul className="list-disc pl-6 space-y-2">
          <li>Website Hosting Service Providers</li>
          <li>Payment Processors</li>
          <li>Data Analytics Services</li>
          <li>Retargeting Platforms</li>
          <li>Sales &amp; Marketing Tools</li>
          <li>Data Storage Service Providers</li>
          <li>Cloud Computing Services</li>
          <li>Communication &amp; Collaboration Tools</li>
        </ul>
        <p>We also may need to share your personal information in the following situations:</p>
        <ul className="list-disc pl-6 space-y-2">
          <li><strong>Business Transfers.</strong> We may share or transfer your information in connection with, or during negotiations of, any merger, sale of company assets, financing, or acquisition of all or a portion of our business to another company.</li>
          <li><strong>When we use Google Maps Platform APIs.</strong> We may share your information with certain Google Maps Platform APIs (e.g., Google Maps API, Places API). Google Maps uses GPS, Wi-Fi, and cell towers to estimate your location. GPS is accurate to about 20 meters, while Wi-Fi and cell towers help improve accuracy when GPS signals are weak, like indoors. This data helps Google Maps provide directions, but it is not always perfectly precise.</li>
        </ul>

        <h2 id="pp-5" className="text-xl font-bold font-display text-foreground mt-10 mb-4">5. DO WE USE COOKIES AND OTHER TRACKING TECHNOLOGIES?</h2>
        <p className="italic"><strong>In Short:</strong> We may use cookies and other tracking technologies to collect and store your information.</p>
        <p>We may use cookies and similar tracking technologies (like web beacons and pixels) to gather information when you interact with our Services. Some online tracking technologies help us maintain the security of our Services, prevent crashes, fix bugs, save your preferences, and assist with basic site functions.</p>
        <p>We also permit third parties and service providers to use online tracking technologies on our Services for analytics and advertising, including to help manage and display advertisements, to tailor advertisements to your interests, or to send abandoned shopping cart reminders (depending on your communication preferences). The third parties and service providers use their technology to provide advertising about products and services tailored to your interests which may appear either on our Services or on other websites.</p>
        <p>To the extent these online tracking technologies are deemed to be a "sale"/"sharing" (which includes targeted advertising, as defined under the applicable laws) under applicable US state laws, you can opt out of these online tracking technologies by submitting a request as described below under section "DO UNITED STATES RESIDENTS HAVE SPECIFIC PRIVACY RIGHTS?"</p>
        <p>Specific information about how we use such technologies and how you can refuse certain cookies is set out in our Cookie Notice.</p>

        <h2 id="pp-6" className="text-xl font-bold font-display text-foreground mt-10 mb-4">6. IS YOUR INFORMATION TRANSFERRED INTERNATIONALLY?</h2>
        <p className="italic"><strong>In Short:</strong> We may transfer, store, and process your information in countries other than your own.</p>
        <p>Our servers are located in the United States. Regardless of your location, please be aware that your information may be transferred to, stored by, and processed by us in our facilities and in the facilities of the third parties with whom we may share your personal information (see "WHEN AND WITH WHOM DO WE SHARE YOUR PERSONAL INFORMATION?" above), including facilities in the United States, and other countries.</p>
        <p>If you are a resident in the European Economic Area (EEA), United Kingdom (UK), or Switzerland, then these countries may not necessarily have data protection laws or other similar laws as comprehensive as those in your country. However, we will take all necessary measures to protect your personal information in accordance with this Privacy Notice and applicable law.</p>
        <p>European Commission's Standard Contractual Clauses:</p>
        <p>We have implemented measures to protect your personal information, including by using the European Commission's Standard Contractual Clauses for transfers of personal information between our group companies and between us and our third-party providers. These clauses require all recipients to protect all personal information that they process originating from the EEA or UK in accordance with European data protection laws and regulations. Our Standard Contractual Clauses can be provided upon request. We have implemented similar appropriate safeguards with our third-party service providers and partners and further details can be provided upon request.</p>

        <h2 id="pp-7" className="text-xl font-bold font-display text-foreground mt-10 mb-4">7. HOW LONG DO WE KEEP YOUR INFORMATION?</h2>
        <p className="italic"><strong>In Short:</strong> We keep your information for as long as necessary to fulfill the purposes outlined in this Privacy Notice unless otherwise required by law.</p>
        <p>We will only keep your personal information for as long as it is necessary for the purposes set out in this Privacy Notice, unless a longer retention period is required or permitted by law (such as tax, accounting, or other legal requirements). No purpose in this notice will require us keeping your personal information for longer than we retain personal information for as long as necessary to fulfill the purposes outlined in this privacy policy, unless a longer retention period is required or permitted by law.</p>
        <p>When we have no ongoing legitimate business need to process your personal information, we will either delete or anonymize such information, or, if this is not possible (for example, because your personal information has been stored in backup archives), then we will securely store your personal information and isolate it from any further processing until deletion is possible.</p>

        <h2 id="pp-8" className="text-xl font-bold font-display text-foreground mt-10 mb-4">8. HOW DO WE KEEP YOUR INFORMATION SAFE?</h2>
        <p className="italic"><strong>In Short:</strong> We aim to protect your personal information through a system of organizational and technical security measures.</p>
        <p>We have implemented appropriate and reasonable technical and organizational security measures designed to protect the security of any personal information we process. However, despite our safeguards and efforts to secure your information, no electronic transmission over the Internet or information storage technology can be guaranteed to be 100% secure, so we cannot promise or guarantee that hackers, cybercriminals, or other unauthorized third parties will not be able to defeat our security and improperly collect, access, steal, or modify your information. Although we will do our best to protect your personal information, transmission of personal information to and from our Services is at your own risk. You should only access the Services within a secure environment.</p>

        <h2 id="pp-9" className="text-xl font-bold font-display text-foreground mt-10 mb-4">9. DO WE COLLECT INFORMATION FROM MINORS?</h2>
        <p className="italic"><strong>In Short:</strong> We do not knowingly collect data from or market to children under 18 years of age or the equivalent as specified by law in your jurisdiction.</p>
        <p>We do not knowingly collect, solicit data from, or market to children under 18 years of age or the equivalent as specified by law in your jurisdiction, nor do we knowingly sell such personal information. By using the Services, you represent that you are at least 18 or the equivalent age as specified by law in your jurisdiction or that you are the parent or guardian of such a minor dependent's use of the Services. If we learn that personal information from users less than 18 years of age or the equivalent age as specified by law in your jurisdiction has been collected, we will deactivate the account and take reasonable measures to promptly delete such data from our records. If you become aware of any data we may have collected from children under age 18 or the equivalent age as specified by law in your jurisdiction, please contact us at <a href="mailto:care@sonoviewforyou.com" className="text-primary underline">care@sonoviewforyou.com</a>.</p>

        <h2 id="pp-10" className="text-xl font-bold font-display text-foreground mt-10 mb-4">10. WHAT ARE YOUR PRIVACY RIGHTS?</h2>
        <p className="italic"><strong>In Short:</strong> Depending on your state of residence in the US or in some regions, such as the European Economic Area (EEA), United Kingdom (UK), Switzerland, and Canada, you have rights that allow you greater access to and control over your personal information. You may review, change, or terminate your account at any time, depending on your country, province, or state of residence.</p>
        <p>In some regions (like the EEA, UK, Switzerland, and Canada), you have certain rights under applicable data protection laws. These may include the right (i) to request access and obtain a copy of your personal information, (ii) to request rectification or erasure; (iii) to restrict the processing of your personal information; (iv) if applicable, to data portability; and (v) not to be subject to automated decision-making. If a decision that produces legal or similarly significant effects is made solely by automated means, we will inform you, explain the main factors, and offer a simple way to request human review. In certain circumstances, you may also have the right to object to the processing of your personal information.</p>
        <p>We will consider and act upon any request in accordance with applicable data protection laws.</p>
        <p>If you are located in the EEA or UK and you believe we are unlawfully processing your personal information, you also have the right to complain to your Member State data protection authority or UK data protection authority.</p>
        <p>If you are located in Switzerland, you may contact the Federal Data Protection and Information Commissioner.</p>
        <p><strong className="underline">Withdrawing your consent:</strong> If we are relying on your consent to process your personal information, which may be express and/or implied consent depending on the applicable law, you have the right to withdraw your consent at any time. You can withdraw your consent at any time by contacting us by using the contact details provided in the section "HOW CAN YOU CONTACT US ABOUT THIS NOTICE?" below.</p>
        <p>However, please note that this will not affect the lawfulness of the processing before its withdrawal nor, when applicable law allows, will it affect the processing of your personal information conducted in reliance on lawful processing grounds other than consent.</p>
        <p><strong className="underline">Opting out of marketing and promotional communications:</strong> You can unsubscribe from our marketing and promotional communications at any time by clicking on the unsubscribe link in the emails that we send, replying "STOP" or "UNSUBSCRIBE" to the SMS messages that we send, or by contacting us using the details provided in the section "HOW CAN YOU CONTACT US ABOUT THIS NOTICE?" below. You will then be removed from the marketing lists. However, we may still communicate with you — for example, to send you service-related messages that are necessary for the administration and use of your account, to respond to service requests, or for other non-marketing purposes.</p>
        <p>No mobile information will be shared with third parties or affiliates for marketing or promotional purposes. Information sharing to subcontractors in support services, such as customer service, is permitted. All other use case categories exclude text messaging originator opt-in data and consent; this information will not be shared with third parties.</p>
        <p><strong className="underline">Cookies and similar technologies:</strong> Most Web browsers are set to accept cookies by default. If you prefer, you can usually choose to set your browser to remove cookies and to reject cookies. If you choose to remove cookies or reject cookies, this could affect certain features or services of our Services.</p>
        <p>If you have questions or comments about your privacy rights, you may email us at <a href="mailto:care@sonoviewforyou.com" className="text-primary underline">care@sonoviewforyou.com</a>.</p>

        <h2 id="pp-11" className="text-xl font-bold font-display text-foreground mt-10 mb-4">11. CONTROLS FOR DO-NOT-TRACK FEATURES</h2>
        <p>Most web browsers and some mobile operating systems and mobile applications include a Do-Not-Track ("DNT") feature or setting you can activate to signal your privacy preference not to have data about your online browsing activities monitored and collected. At this stage, no uniform technology standard for recognizing and implementing DNT signals has been finalized. As such, we do not currently respond to DNT browser signals or any other mechanism that automatically communicates your choice not to be tracked online. If a standard for online tracking is adopted that we must follow in the future, we will inform you about that practice in a revised version of this Privacy Notice.</p>
        <p>California law requires us to let you know how we respond to web browser DNT signals. Because there is currently not an industry or legal standard for recognizing or honoring DNT signals, we do not respond to them at this time.</p>

        <h2 id="pp-12" className="text-xl font-bold font-display text-foreground mt-10 mb-4">12. DO UNITED STATES RESIDENTS HAVE SPECIFIC PRIVACY RIGHTS?</h2>
        <p className="italic"><strong>In Short:</strong> If you are a resident of California, Colorado, Connecticut, Delaware, Florida, Indiana, Iowa, Kentucky, Maryland, Minnesota, Montana, Nebraska, New Hampshire, New Jersey, Oregon, Rhode Island, Tennessee, Texas, Utah, or Virginia, you may have the right to request access to and receive details about the personal information we maintain about you and how we have processed it, correct inaccuracies, get a copy of, or delete your personal information. You may also have the right to withdraw your consent to our processing of your personal information. These rights may be limited in some circumstances by applicable law. More information is provided below.</p>

        <h3 className="text-base font-bold text-foreground mt-6 mb-2">Categories of Personal Information We Collect</h3>
        <p>The table below shows the categories of personal information we have collected in the past twelve (12) months. The table includes illustrative examples of each category and does not reflect the personal information we collect from you. For a comprehensive inventory of all personal information we process, please refer to the section "WHAT INFORMATION DO WE COLLECT?"</p>

        <div className="overflow-x-auto my-4">
          <table className="w-full border-collapse border border-border text-xs">
            <thead className="bg-muted">
              <tr>
                <th className="border border-border p-2 text-left font-bold">Category</th>
                <th className="border border-border p-2 text-left font-bold">Examples</th>
                <th className="border border-border p-2 text-left font-bold">Collected</th>
              </tr>
            </thead>
            <tbody>
              <tr><td className="border border-border p-2">A. Identifiers</td><td className="border border-border p-2">Contact details, such as real name, alias, postal address, telephone or mobile contact number, unique personal identifier, online identifier, Internet Protocol address, email address, and account name</td><td className="border border-border p-2">YES</td></tr>
              <tr><td className="border border-border p-2">B. Personal information as defined in the California Customer Records statute</td><td className="border border-border p-2">Name, contact information, education, employment, employment history, and financial information</td><td className="border border-border p-2">YES</td></tr>
              <tr><td className="border border-border p-2">C. Protected classification characteristics under state or federal law</td><td className="border border-border p-2">Gender, age, date of birth, race and ethnicity, national origin, marital status, and other demographic data</td><td className="border border-border p-2">YES</td></tr>
              <tr><td className="border border-border p-2">D. Commercial information</td><td className="border border-border p-2">Transaction information, purchase history, financial details, and payment information</td><td className="border border-border p-2">YES</td></tr>
              <tr><td className="border border-border p-2">E. Biometric information</td><td className="border border-border p-2">Fingerprints and voiceprints</td><td className="border border-border p-2">NO</td></tr>
              <tr><td className="border border-border p-2">F. Internet or other similar network activity</td><td className="border border-border p-2">Browsing history, search history, online behavior, interest data, and interactions with our and other websites, applications, systems, and advertisements</td><td className="border border-border p-2">YES</td></tr>
              <tr><td className="border border-border p-2">G. Geolocation data</td><td className="border border-border p-2">Device location</td><td className="border border-border p-2">YES</td></tr>
              <tr><td className="border border-border p-2">H. Audio, electronic, sensory, or similar information</td><td className="border border-border p-2">Images and audio, video or call recordings created in connection with our business activities</td><td className="border border-border p-2">NO</td></tr>
              <tr><td className="border border-border p-2">I. Professional or employment-related information</td><td className="border border-border p-2">Business contact details in order to provide you our Services at a business level or job title, work history, and professional qualifications if you apply for a job with us</td><td className="border border-border p-2">NO</td></tr>
              <tr><td className="border border-border p-2">J. Education Information</td><td className="border border-border p-2">Student records and directory information</td><td className="border border-border p-2">NO</td></tr>
              <tr><td className="border border-border p-2">K. Inferences drawn from collected personal information</td><td className="border border-border p-2">Inferences drawn from any of the collected personal information listed above to create a profile or summary about, for example, an individual's preferences and characteristics</td><td className="border border-border p-2">NO</td></tr>
              <tr><td className="border border-border p-2">L. Sensitive personal Information</td><td className="border border-border p-2">Health data and debit or credit card numbers</td><td className="border border-border p-2">YES</td></tr>
            </tbody>
          </table>
        </div>

        <p>We only collect sensitive personal information, as defined by applicable privacy laws or the purposes allowed by law or with your consent. Sensitive personal information may be used, or disclosed to a service provider or contractor, for additional, specified purposes. You may have the right to limit the use or disclosure of your sensitive personal information. We do not collect or process sensitive personal information for the purpose of inferring characteristics about you.</p>
        <p>We may also collect other personal information outside of these categories through instances where you interact with us in person, online, or by phone or mail in the context of:</p>
        <ul className="list-disc pl-6 space-y-2">
          <li>Receiving help through our customer support channels;</li>
          <li>Participation in customer surveys or contests; and</li>
          <li>Facilitation in the delivery of our Services and to respond to your inquiries.</li>
        </ul>
        <p>We will use and retain the collected personal information as needed to provide the Services or for:</p>
        <ul className="list-disc pl-6 space-y-2">
          <li>Category A - As long as the user has an account with us</li>
          <li>Category B - As long as the user has an account with us</li>
          <li>Category C - As long as the user has an account with us</li>
          <li>Category D - As long as the user has an account with us</li>
          <li>Category F - As long as the user has an account with us</li>
          <li>Category G - As long as the user has an account with us</li>
          <li>Category L - As long as the user has an account with us</li>
        </ul>

        <h3 className="text-base font-bold text-foreground mt-6 mb-2">Sources of Personal Information</h3>
        <p>Learn more about the sources of personal information we collect in "WHAT INFORMATION DO WE COLLECT?"</p>

        <h3 className="text-base font-bold text-foreground mt-6 mb-2">How We Use and Share Personal Information</h3>
        <p>Learn more about how we use your personal information in the section, "HOW DO WE PROCESS YOUR INFORMATION?"</p>
        <p>We collect and share your personal information through:</p>
        <ul className="list-disc pl-6 space-y-2">
          <li>Targeting cookies/Marketing cookies</li>
          <li>Social media cookies</li>
          <li>Beacons/Pixels/Tags</li>
        </ul>

        <p><strong>Will your information be shared with anyone else?</strong></p>
        <p>We may disclose your personal information with our service providers pursuant to a written contract between us and each service provider. Learn more about how we disclose personal information to in the section, "WHEN AND WITH WHOM DO WE SHARE YOUR PERSONAL INFORMATION?"</p>
        <p>We may use your personal information for our own business purposes, such as for undertaking internal research for technological development and demonstration. This is not considered to be "selling" of your personal information.</p>
        <p>We have not sold or shared any personal information to third parties for a business or commercial purpose in the preceding twelve (12) months. We have disclosed the following categories of personal information to third parties for a business or commercial purpose in the preceding twelve (12) months:</p>
        <ul className="list-disc pl-6 space-y-2">
          <li>Category A. Identifiers</li>
          <li>Category B. Personal information as defined in the California Customer Records law</li>
          <li>Category D. Commercial information</li>
          <li>Category F. Internet or other electronic network activity information</li>
          <li>Category G. Geolocation data</li>
          <li>Category L. Sensitive personal information</li>
        </ul>
        <p>The categories of third parties to whom we disclosed personal information for a business or commercial purpose can be found under "WHEN AND WITH WHOM DO WE SHARE YOUR PERSONAL INFORMATION?"</p>

        <h3 className="text-base font-bold text-foreground mt-6 mb-2">Your Rights</h3>
        <p>You have rights under certain US state data protection laws. However, these rights are not absolute, and in certain cases, we may decline your request as permitted by law. These rights include:</p>
        <ul className="list-disc pl-6 space-y-2">
          <li><strong>Right to know</strong> whether or not we are processing your personal data</li>
          <li><strong>Right to access</strong> your personal data</li>
          <li><strong>Right to correct</strong> inaccuracies in your personal data</li>
          <li><strong>Right to request</strong> the deletion of your personal data</li>
          <li><strong>Right to obtain a copy</strong> of the personal data you previously shared with us</li>
          <li><strong>Right to non-discrimination</strong> for exercising your rights</li>
          <li><strong>Right to opt out</strong> of the processing of your personal data if it is used for targeted advertising (or sharing as defined under California's privacy law), the sale of personal data, or profiling in furtherance of decisions that produce legal or similarly significant effects ("profiling")</li>
        </ul>
        <p>Depending upon the state where you live, you may also have the following rights:</p>
        <ul className="list-disc pl-6 space-y-2">
          <li>Right to access the categories of personal data being processed (as permitted by applicable law, including the privacy law in Minnesota)</li>
          <li>Right to obtain a list of the categories of third parties to which we have disclosed personal data (as permitted by applicable law, including the privacy law in California, Delaware, and Maryland)</li>
          <li>Right to obtain a list of specific third parties to which we have disclosed personal data (as permitted by applicable law, including the privacy law in Minnesota and Oregon)</li>
          <li>Right to obtain a list of third parties to which we have sold personal data (as permitted by applicable law, including the privacy law in Connecticut)</li>
          <li>Right to review, understand, question, and depending on where you live, correct how personal data has been profiled (as permitted by applicable law, including the privacy law in Connecticut and Minnesota)</li>
          <li>Right to limit use and disclosure of sensitive personal data (as permitted by applicable law, including the privacy law in California)</li>
          <li>Right to opt out of the collection of sensitive data and personal data collected through the operation of a voice or facial recognition feature (as permitted by applicable law, including the privacy law in Florida)</li>
        </ul>

        <h3 className="text-base font-bold text-foreground mt-6 mb-2">How to Exercise Your Rights</h3>
        <p>To exercise these rights, you can contact us by submitting a data subject access request, by emailing us at <a href="mailto:care@sonoviewforyou.com" className="text-primary underline">care@sonoviewforyou.com</a>, by calling toll-free at (775) 305-7868, or by referring to the contact details at the bottom of this document.</p>
        <p>Under certain US state data protection laws, you can designate an authorized agent to make a request on your behalf. We may deny a request from an authorized agent that does not submit proof that they have been validly authorized to act on your behalf in accordance with applicable laws.</p>

        <h3 className="text-base font-bold text-foreground mt-6 mb-2">Request Verification</h3>
        <p>Upon receiving your request, we will need to verify your identity to determine you are the same person about whom we have the information in our system. We will only use personal information provided in your request to verify your identity or authority to make the request. However, if we cannot verify your identity from the information already maintained by us, we may request that you provide additional information for the purposes of verifying your identity and for security or fraud-prevention purposes.</p>
        <p>If you submit the request through an authorized agent, we may need to collect additional information to verify your identity before processing your request and the agent will need to provide a written and signed permission from you to submit such request on your behalf.</p>

        <h3 className="text-base font-bold text-foreground mt-6 mb-2">Appeals</h3>
        <p>Under certain US state data protection laws, if we decline to take action regarding your request, you may appeal our decision by emailing us at <a href="mailto:care@sonoviewforyou.com" className="text-primary underline">care@sonoviewforyou.com</a>. We will inform you in writing of any action taken or not taken in response to the appeal, including a written explanation of the reasons for the decisions. If your appeal is denied, you may submit a complaint to your state attorney general.</p>

        <h3 className="text-base font-bold text-foreground mt-6 mb-2">California "Shine The Light" Law</h3>
        <p>California Civil Code Section 1798.83, also known as the "Shine The Light" law, permits our users who are California residents to request and obtain from us, once a year and free of charge, information about categories of personal information (if any) we disclosed to third parties for direct marketing purposes and the names and addresses of all third parties with which we shared personal information in the immediately preceding calendar year. If you are a California resident and would like to make such a request, please submit your request in writing to us by using the contact details provided in the section "HOW CAN YOU CONTACT US ABOUT THIS NOTICE?"</p>

        <h2 id="pp-13" className="text-xl font-bold font-display text-foreground mt-10 mb-4">13. DO WE MAKE UPDATES TO THIS NOTICE?</h2>
        <p className="italic"><strong>In Short:</strong> Yes, we will update this notice as necessary to stay compliant with relevant laws.</p>
        <p>We may update this Privacy Notice from time to time. The updated version will be indicated by an updated "Revised" date at the top of this Privacy Notice. If we make material changes to this Privacy Notice, we may notify you either by prominently posting a notice of such changes or by directly sending you a notification. We encourage you to review this Privacy Notice frequently to be informed of how we are protecting your information.</p>

        <h2 id="pp-14" className="text-xl font-bold font-display text-foreground mt-10 mb-4">14. HOW CAN YOU CONTACT US ABOUT THIS NOTICE?</h2>
        <p>If you have questions or comments about this notice, you may email us at <a href="mailto:care@sonoviewforyou.com" className="text-primary underline">care@sonoviewforyou.com</a> or contact us by post at:</p>
        <address className="not-italic">
          Sonoview For You LLC<br />
          255 Bell Street, Suite 104<br />
          Reno, NV 89503<br />
          United States
        </address>

        <h2 id="pp-15" className="text-xl font-bold font-display text-foreground mt-10 mb-4">15. HOW CAN YOU REVIEW, UPDATE, OR DELETE THE DATA WE COLLECT FROM YOU?</h2>
        <p>Based on the applicable laws of your country or state of residence in the US, you may have the right to request access to the personal information we collect from you, details about how we have processed it, correct inaccuracies, or delete your personal information. You may also have the right to withdraw your consent to our processing of your personal information. These rights may be limited in some circumstances by applicable law. To request to review, update, or delete your personal information, please contact us at <a href="mailto:care@sonoviewforyou.com" className="text-primary underline">care@sonoviewforyou.com</a>.</p>
      </section>
    </main>
    <Footer />
  </>
);

export default PrivacyPolicy;
